package com.example.dudhbill

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import org.json.JSONArray
import org.json.JSONObject
import java.time.YearMonth

data class Customer(val id:String,val name:String,val rate:Double)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        setContent { MaterialTheme { MilkApp(this) } }
    }
}
@Composable
fun MilkApp(ctx:Context) {
    val prefs=remember { ctx.getSharedPreferences("dudh_data",Context.MODE_PRIVATE) }
    var pin by remember { mutableStateOf(prefs.getString("pin","1234") ?: "1234") }
    var unlocked by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var customers by remember { mutableStateOf(loadCustomers(prefs)) }
    var selected by remember { mutableStateOf("") }
    var month by remember { mutableStateOf(YearMonth.now().toString()) }
    var newName by remember { mutableStateOf("") }
    var newRate by remember { mutableStateOf("60") }
    var refresh by remember { mutableIntStateOf(0) }
    fun saveCustomers() { val a=JSONArray(); customers.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("rate",it.rate)) }; prefs.edit().putString("customers",a.toString()).apply() }
    fun getMilk(id:String,day:Int)=prefs.getString("milk_${id}_${month}_$day","") ?: ""
    fun setMilk(id:String,day:Int,v:String) { prefs.edit().putString("milk_${id}_${month}_$day",v).apply(); refresh++ }
    fun getPaid(id:String)=prefs.getString("paid_${id}_$month","0")?.toDoubleOrNull() ?: 0.0
    fun setPaid(id:String,v:String) { prefs.edit().putString("paid_${id}_$month",v).apply(); refresh++ }
    val days=runCatching { YearMonth.parse(month).lengthOfMonth() }.getOrDefault(30)
    if (!unlocked) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement=Arrangement.Center) {
            Text("🥛 दूध बिल", style=MaterialTheme.typography.headlineLarge)
            Text("मालकाचा PIN टाका")
            OutlinedTextField(pinInput,{pinInput=it},label={Text("PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
            Button(onClick={ if(pinInput==pin) unlocked=true }) { Text("उघडा") }
            Text("पहिल्यांदा वापरताना तात्पुरता PIN 1234 आहे. सेटिंगमधून बदला.")
        }; return
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("🥛 दूध बिल",style=MaterialTheme.typography.headlineLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(month,{month=it},label={Text("महिना YYYY-MM")},modifier=Modifier.weight(1f))
            Button(onClick={unlocked=false;pinInput=""}) { Text("लॉक") }
        }
        if(selected.isBlank()) {
            Text("ग्राहक (${customers.size}/50)",style=MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(newName,{newName=it},label={Text("नाव")},modifier=Modifier.weight(1f))
                OutlinedTextField(newRate,{newRate=it},label={Text("दर ₹/लि.")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            }
            Button(onClick={ if(newName.isNotBlank() && customers.size<50) { customers=customers+Customer(System.currentTimeMillis().toString(),newName,newRate.toDoubleOrNull()?:60.0); saveCustomers(); newName="" } }) { Text("ग्राहक जोडा") }
            val total=customers.sumOf { c -> (1..days).sumOf { getMilk(c.id,it).toDoubleOrNull()?:0.0 }*c.rate }
            val paid=customers.sumOf { getPaid(it.id) }
            Text("सर्व ग्राहकांचे बिल: ₹${"%.2f".format(total)}")
            Text("जमा: ₹${"%.2f".format(paid)}   बाकी: ₹${"%.2f".format(total-paid)}")
            LazyColumn { items(customers) { c -> Card(Modifier.fillMaxWidth().padding(vertical=4.dp),onClick={selected=c.id}) { Column(Modifier.padding(12.dp)) { Text(c.name,style=MaterialTheme.typography.titleMedium); val bill=(1..days).sumOf { getMilk(c.id,it).toDoubleOrNull()?:0.0 }*c.rate; val due=bill-getPaid(c.id); Text("बिल ₹${"%.2f".format(bill)} • बाकी ₹${"%.2f".format(due)}") } } } }
        } else {
            val c=customers.firstOrNull { it.id==selected }
            if(c!=null) {
                TextButton(onClick={selected=""}) { Text("← ग्राहक यादी") }
                Text(c.name,style=MaterialTheme.typography.titleLarge)
                Text("दर ₹${c.rate}/लिटर")
                LazyColumn(Modifier.weight(1f)) {
                    items((1..days).toList()) { d ->
                        var value by remember(month,c.id,d,refresh) { mutableStateOf(getMilk(c.id,d)) }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Text("$d तारीख",Modifier.width(76.dp))
                            OutlinedTextField(value,{value=it;setMilk(c.id,d,it)},label={Text("लिटर (रिकामे = –)")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
                            Text(if(value.isBlank()) "–" else "₹${"%.0f".format((value.toDoubleOrNull()?:0.0)*c.rate)}")
                        }
                    }
                }
                val bill=(1..days).sumOf { getMilk(c.id,it).toDoubleOrNull()?:0.0 }*c.rate
                Text("एकूण बिल: ₹${"%.2f".format(bill)}")
                var paidText by remember(c.id,month,refresh) { mutableStateOf(getPaid(c.id).toString()) }
                OutlinedTextField(paidText,{paidText=it;setPaid(c.id,it)},label={Text("जमा रक्कम")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
                Text("बाकी: ₹${"%.2f".format(bill-getPaid(c.id))}")
            }
        }
    }
}
fun loadCustomers(prefs:android.content.SharedPreferences):List<Customer> = runCatching {
    val a=JSONArray(prefs.getString("customers","[]"))
    (0 until a.length()).map { val o=a.getJSONObject(it); Customer(o.getString("id"),o.getString("name"),o.getDouble("rate")) }
}.getOrDefault(emptyList())
